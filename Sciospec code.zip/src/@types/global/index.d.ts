export {};

declare global {
	namespace ReactTailwindTemplate {}
}
