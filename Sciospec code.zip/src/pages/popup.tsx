import { FC } from "react";

export const PopupPage: FC = () => {
	return <div>Hello popup</div>;
};
