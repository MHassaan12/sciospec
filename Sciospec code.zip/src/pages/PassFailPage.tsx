import React, { FC } from "react";

const PassFailPage: FC = () => {
	return (
		<div className="h-full flex justify-center items-center text-2xl text-white">
			PassFail Page Coming Soon...
		</div>
	);
};

export default PassFailPage;
