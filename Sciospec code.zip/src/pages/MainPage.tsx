import React, { FC } from "react";
import { SciospecLogo } from "../assets/SvgIcons";

const MainPage: FC = () => {
	return (
		<div className="h-full flex flex-col justify-center items-start text-2xl text-white">
			<div className="flex items-center   w-[72%] border-4 border-custom-primary m-4">
				<div className="w-[20%] bg-custom-primary pb-10 text-center">
					<div className="text-7xl ">
						R<sub>p</sub>
					</div>
					<div className="text-7xl mt-5">
						C<sub>p</sub>
					</div>
				</div>
				<div className="w-[70%] text-center">
					<div className="text-7xl ml-28 ">
						<div>
							42.344
							<span className="ml-14">&#937;</span>
						</div>
						<div className="text-lg text-zinc-400 text-end mr-40">
							<span>&#177;</span>
							0.08%
							<span className="ml-1">&#177;</span>1
							<span className="ml-1">m&#937;</span>
						</div>
					</div>
					<div className="text-7xl ml-36">
						2.701 <span className="ml-6">pF</span>
						<div className="text-lg text-zinc-400 text-end mr-40">
							<span>&#177;</span>
							3.42%
							<span className="ml-1">&#177;</span>0.1
							<span className="ml-1">pF</span>
						</div>
					</div>
				</div>
			</div>
			<div className="flex items-center   w-[72%] border-4 border-custom-primary m-4">
				<div className="w-[20%] bg-custom-primary pb-10 text-center">
					<div className="text-7xl ">| Z |</div>
					<div className="text-7xl mt-5">&#8861;</div>
				</div>
				<div className="w-[70%] text-center">
					<div className="text-7xl ml-28 ">
						<div>
							41.004
							<span className="ml-14">&#937;</span>
						</div>
					</div>
					<div className="text-7xl ml-32 mt-6">
						-8.701 <span className="ml-16">&#176;</span>
					</div>
				</div>
			</div>
		</div>
	);
};

export default MainPage;
