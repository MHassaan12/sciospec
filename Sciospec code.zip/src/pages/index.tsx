export { default as Main } from "./MainPage";
export { default as Setting } from "./SettingPage";
export { default as PassFail } from "./PassFailPage";
export { default as TimeTrace } from "./TimeTracePage";
