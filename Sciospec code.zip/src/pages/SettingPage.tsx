import React, { FC } from "react";

const SettingPage: FC = () => {
	return (
		<div className="h-full flex justify-center items-center text-2xl text-white">
			Setting Page Coming Soon...
		</div>
	);
};

export default SettingPage;
